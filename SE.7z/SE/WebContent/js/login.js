
var app = angular.module('MainPage',['ngMaterial']);
app.controller('buttonController',buttonController);
function buttonController ($scope , $mdDialog , $http) {
	// For Dialog Box To open Up
	$scope.showlogin = function (ev){
		$mdDialog.show({
			controller: buttonDialogController,
		      templateUrl: 'login.tmpl.html',
		      parent: angular.element(document.body),
		      targetEvent: ev,
		      clickOutsideToClose:true,
		     // fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
			
		}
		);
		
	};
	
	$scope.paymentAPI = function(){
		// The function is used to create the payment gateway
		
	};
	
	
	
	// Function inside the Pop up of login
	function buttonDialogController ($scope ,$mdDialog , $http){
		$scope.cancel= function() {
			$mdDialog.cancel();
		};
		
		$scope.status = "DIalog";
		$scope.loginfunc = function () {
			
			var uname = $scope.username;
			var upass= $scope.userpass;
			var json = uname+ " " + upass;
			$scope.status = json;
			var data = {
					name : uname,
					pass : upass
			};
			
			data = JSON.stringify(data);
			var url = './api/payment.java';
			$http.post(url,data).then(function(response){
				$scope.status = "Data Submitted Succesfully";
				console.log(url);
				console.log(response);
			}, function(response) {
				$scope.status = "Service Not Exists";
			});
		
		};
	}
}

